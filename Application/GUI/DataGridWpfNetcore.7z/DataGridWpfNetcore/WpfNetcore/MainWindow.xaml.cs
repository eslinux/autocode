﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfNetcore
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            if (dgvTest.ItemsSource == null)
            {
                dgvTest.ItemsSource = DataManagement.Instance.dgvRows;
            }
        }

        private async void BtnCreateData_Click(object sender, RoutedEventArgs e)
        {
            SetUiState(true);
            await Task.Run(() =>
            {
                DataManagement.Instance.GetData();
            });

            //DataManagement.Instance.GetData();

            dgvTest.UpdateLayout();
            SetUiState(false);
        }

        private async void BtnDeteleData_Click(object sender, RoutedEventArgs e)
        {

            SetUiState(true);
            await Task.Run(() =>
            {
                DataManagement.Instance.DeleteData();
            });

            //DataManagement.Instance.GetData();

            dgvTest.UpdateLayout();
            SetUiState(false);
        }

        private void SetUiState(bool isProcessing)
        {
            BtnCreateData.IsEnabled = !isProcessing;
            BtnDeteleData.IsEnabled = !isProcessing;

            LbStatus.Content = isProcessing ? "Processing ..." : String.Empty;
            
        }
    }
}
