﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Data;

namespace WpfNetcore
{
    class DataManagement
    {
        private object _lock = new object();
        public ObservableCollection<Employee> dgvRows = new ObservableCollection<Employee>();

        //Instance delegate
        private static DataManagement _instance = null;
        public static DataManagement Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DataManagement();
                return _instance;
            }
        }

        public DataManagement()
        {
            BindingOperations.EnableCollectionSynchronization(this.dgvRows, this._lock);
        }


        public bool GetData()
        {

            for (int i = 0; i < 100; i++)
            {
                dgvRows.Add(new Employee() { 
                    ID = dgvRows.Count + 1,
                    Name = $"my name {i}"
                });

                Thread.Sleep(100);
            }

            return true;
        }

        public bool DeleteData()
        {
            while(dgvRows.Count > 0)
            {
                dgvRows.RemoveAt(dgvRows.Count - 1);
                Thread.Sleep(100);
            }


            return true;
        }


    }


    public class Employee : INotifyPropertyChanged
    {
        #region PropertyChangedEventHandler
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaiseProperChanged([CallerMemberName] string propertyname = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion


        #region Column field

        //item id
        private int id;

        public int ID
        {
            get => id;
            set
            {
                id = value;
                RaiseProperChanged();
            }
        }

        private string name;

        public string Name
        {
            get => name;
            set
            {
                name = value;
                RaiseProperChanged();
            }
        }

        #endregion

    }
}
