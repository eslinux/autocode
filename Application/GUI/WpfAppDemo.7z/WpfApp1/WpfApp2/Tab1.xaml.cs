﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Tab1.xaml
    /// </summary>
    public partial class Tab1 : UserControl
    {
        ObservableCollection<Employee> dgvData = new ObservableCollection<Employee>();
        DgvDataContext dgvDataContext = new DgvDataContext();

        public Tab1()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

            dgvuser.DataContext = dgvDataContext;
            //dgvuser.RowDetailsVisibilityMode = DataGridRowDetailsVisibilityMode.Collapsed;
        }

        private void CallBackTest(int rowindex)
        {
            Console.WriteLine($"CallBackTest row={rowindex}");
            //dgvData[0].IsHidden = rowindex == 1;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("\n-------->");
            foreach (Employee row in dgvData)
            {
                Console.WriteLine("id: {0}, enable: {3}, value: {1}, type: {2}", row.ID, row.CbValue, row.CbType, row.WasReElected);
            }



            dgvData = Employee.GetEmployees(ref dgvData, CallBackTest);


            if (dgvuser.ItemsSource == null)
            {
                //ListCollectionView collectionView = new ListCollectionView(dgvData);
                //collectionView.GroupDescriptions.Add(new PropertyGroupDescription("Name"));
                //dgvuser.ItemsSource = collectionView;

                dgvuser.ItemsSource = dgvData;
            }

            dgvuser.UpdateLayout();
            //CollectionViewSource.GetDefaultView(dgvuser.ItemsSource).Refresh();
            //dgvuser.Items.Refresh();
            Console.WriteLine("Button_Click");


            var mySource = Enumerable.Range(1, 1000).ToList();
            //_ = Task.Factory.StartNew(() => CalculateMyOperation(mySource));

            Task.Run(() => CalculateMyOperation(mySource));

        }

        private void CalculateMyOperation(List<int> values)
        {
            foreach (var i in values)
            {
                var currentProgress = i;
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    //myLabel.Content = "Updating..." + currentProgress;
                    tb_colIndex.Text = i.ToString();
                }), DispatcherPriority.Background);
            }


            Dispatcher.BeginInvoke(new Action(() =>
            {
                foreach (var row in dgvData)
                {
                    row.SwitchRowDetalsExpand2(true);
                }
            }), DispatcherPriority.Background);
        }


        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            dgvData.Clear();
            if (dgvuser.ItemsSource == null)
            {
                dgvuser.ItemsSource = dgvData;
            }
            dgvuser.Items.Refresh();
            Console.WriteLine("btnDelete_Click");
        }

        private void CkbEnable_Checked(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("ckbEnable_Checked: " + ((CheckBox)sender).IsChecked);

            //show or hiden detai for all row
            //dgvuser.RowDetailsVisibilityMode = ((CheckBox)sender).IsChecked == true
            //    ? DataGridRowDetailsVisibilityMode.Visible //show detail for all row 
            //    : DataGridRowDetailsVisibilityMode.VisibleWhenSelected; //show detail for selected row only


        }

        private void OnChecked(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("OnChecked: {0}", ((DataGridCell)sender).Tag);
        }

        private void HiddenCol_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                int col = int.Parse(tb_colIndex.Text);
                dgvuser.Columns[col].Visibility = dgvuser.Columns[col].Visibility == Visibility.Hidden ? Visibility.Visible : Visibility.Hidden;

            }
            catch
            {

            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string btn = (string)((Button)sender).Tag;
            Console.WriteLine($"Button_Click_1 tag={btn}");
            dgvDataContext.SetThreeState();
            dgvDataContext.SetFilter(btn);
        }

        private void Expander_Expanded(object sender, RoutedEventArgs e)
        {
            Button expandCollapseButton = (Button)sender;
            Console.WriteLine($"Clicked noIndex = {expandCollapseButton.Tag}");

            int noIndex = int.Parse(expandCollapseButton.Tag.ToString());

            dgvData[noIndex - 1].SwitchRowDetalsExpand();

            //Button expandCollapseButton = (Button)sender;
            //DataGridRow selectedRow = DataGridRow.GetRowContainingElement(expandCollapseButton);
            //if (null != expandCollapseButton && "+" == expandCollapseButton.Content.ToString())
            //{
            //    selectedRow.DetailsVisibility = Visibility.Visible;
            //    expandCollapseButton.Content = "-";
            //}
            //else
            //{
            //    selectedRow.DetailsVisibility = Visibility.Collapsed;
            //    expandCollapseButton.Content = "+";
            //}


            //for (var vis = sender as Visual; vis != null; vis = VisualTreeHelper.GetParent(vis) as Visual)
            //if (vis is DataGridRow row)
            //{
            //    Console.WriteLine($"Clicked in = {row.GetIndex()}");

            //    //row.DetailsVisibility = row.DetailsVisibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
            //    break;
            //}
        }

        private void btnExpand_Click(object sender, RoutedEventArgs e)
        {
            foreach (var row in dgvData)
            {
                row.SwitchRowDetalsExpand2(true);
            }
        }
    }

    #region Dgv data source (INotifyPropertyChanged)
    public class Employee : INotifyPropertyChanged
    {
        #region PropertyChangedEventHandler
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaiseProperChanged([CallerMemberName] string propertyname = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion

        private Action<int> callback;

        public Employee(Action<int> cb)
        {

            ValueItems = new List<string>
            {
                "anh yeu em",
                "mai mai mot tinh yeu",
                "tinh don phuong"
            };

            TypeItems = new List<string>
            {
                "type 1",
                "type 2",
                "type 3",
                "type 5",
                "type 6"
            };

            callback = cb;
        }

        #region Column field
        public bool IsInit { set; get; } = true;

        //row index
        public int RowIndex { set; get; } = 0;


        //item id
        private string id;

        public string ID
        {
            get => id;
            set
            {
                id = value;
                RaiseProperChanged();
            }
        }

        private string name;

        public string Name
        {
            get => name;
            set
            {
                name = value;
                RaiseProperChanged();
            }
        }

        private string title;

        public string Title
        {
            get => title;
            set
            {
                title = value;
                RaiseProperChanged();
            }
        }

        private bool? wasReElected = true;
        private bool? preWasReElected = true;

        public bool? WasReElected
        {
            get => wasReElected;
            set
            {
                wasReElected = value;
                if (wasReElected != null)
                {
                    preWasReElected = wasReElected;
                }
                else
                {
                    wasReElected = !preWasReElected;
                }


                RaiseProperChanged();
                if (IsInit)
                {
                    return;
                }

                callback?.Invoke(RowIndex);
            }
        }


        public List<string> ValueItems { set; get; }

        private string cbValue;
        public string CbValue
        {
            get => cbValue;
            set
            {
                cbValue = value;
                RaiseProperChanged();
            }
        }


        public List<string> TypeItems { set; get; }
        private string cbType;
        public string CbType
        {
            get => cbType;
            set
            {
                cbType = value;
                RaiseProperChanged();

                //test checkbox three state




                //run other process
                //Console.WriteLine("set CbType: IsInit {0}", IsInit);
                if (IsInit) { return; }
                CbValue = cbType;
            }
        }


        #endregion

        #region Show info
        private bool isHidden { set; get; } = false;
        public bool IsHidden
        {
            get => isHidden;
            set
            {
                isHidden = value;
                RaiseProperChanged();
            }
        }






        private string isExpandedDetail { set; get; } = "Collapsed";//Visible, Collapsed, Hidden
        public string IsExpandedDetail
        {
            get => isExpandedDetail;
            set
            {
                isExpandedDetail = value;
                RaiseProperChanged();
            }
        }
        private string expandImage { set; get; } = "+";//Visible, Collapsed, Hidden
        public string ExpandImage
        {
            get => expandImage;
            set
            {
                expandImage = value;
                RaiseProperChanged();
            }
        }
        public void SwitchRowDetalsExpand()
        {
            if (IsExpandedDetail == "Collapsed")
            {
                IsExpandedDetail = "Visible";
                ExpandImage = "-";
            }
            else
            {
                IsExpandedDetail = "Collapsed";
                ExpandImage = "+";
            }
        }
        public void SwitchRowDetalsExpand2(bool isExpand)
        {
            if (isExpand)
            {
                IsExpandedDetail = "Visible";
                ExpandImage = "-";
            }
            else
            {
                IsExpandedDetail = "Collapsed";
                ExpandImage = "+";
            }
        }


        //private bool isExpandRow { set; get; } = false;
        //public bool IsExpandRow
        //{
        //    get => isExpandRow;
        //    set
        //    {
        //        isExpandRow = value;
        //        RaiseProperChanged();
        //    }
        //}

        #endregion

        #region Create data for datagrid
        public static ObservableCollection<Employee> GetEmployees(ref ObservableCollection<Employee> employees, Action<int> cb)
        {
            if (employees == null)
            {
                employees = new ObservableCollection<Employee>();
            }

            for (int i = 0; i < 1; i++)
            {
                employees.Add(new Employee(cb)
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Ali",
                    Title = "Minister aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                    CbValue = "aa",
                    CbType = "type 1",
                    WasReElected = true
                }); ; ;

                employees.Add(new Employee(cb)
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Ahmed",
                    Title = "CM",
                    CbValue = "bb",
                    CbType = "type 1",
                    WasReElected = false
                });

                employees.Add(new Employee(cb)
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Amjad",
                    Title = "PM",
                    CbValue = "cc",
                    CbType = "type 1",
                    WasReElected = true

                });

                employees.Add(new Employee(cb)
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Waqas",
                    Title = "Minister",
                    CbValue = "dd",
                    CbType = "type 1",
                    WasReElected = false
                });

                employees.Add(new Employee(cb)
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Bilal",
                    Title = "Minister",
                    CbValue = "ee",
                    CbType = "type 1",
                    WasReElected = true
                });

                employees.Add(new Employee(cb)
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Waqar",
                    Title = "Minister",
                    CbValue = "ff",
                    CbType = "type 1",
                    WasReElected = false
                });
            }

            foreach (Employee row in employees)
            {
                row.IsInit = false;
            }
            return employees;
        }
        #endregion

    }

    public class DgvDataContext : INotifyPropertyChanged
    {
        #region PropertyChangedEventHandler
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaiseProperChanged([CallerMemberName] string propertyname = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion

        #region Col Enable
        private bool? isEnable = false;
        public bool? IsEnable
        {
            get => isEnable;
            set
            {
                isEnable = value;
                RaiseProperChanged();
            }
        }
        public void SetThreeState()
        {
            isEnable = null;
            RaiseProperChanged("IsEnable");
        }
        #endregion

        #region Col title
        private string title123 = "Darling";
        public string Title123
        {
            get => title123;
            set
            {
                title123 = value;
                RaiseProperChanged();
            }
        }
        #endregion

        #region Name Filter button
        private BtnFilterDataContext btnNameFilter = new BtnFilterDataContext();

        public BtnFilterDataContext BtnNameFilter
        {
            get => btnNameFilter;
            set
            {
                btnNameFilter = value;
                RaiseProperChanged();
            }
        }
        #endregion
        #region Title Filter button
        private BtnFilterDataContext btnTitleFilter = new BtnFilterDataContext();

        public BtnFilterDataContext BtnTitleFilter
        {
            get => btnTitleFilter;
            set
            {
                btnTitleFilter = value;
                RaiseProperChanged();
            }
        }
        #endregion

        public void SetFilter(string btnName)
        {
            if (btnName == "Name")
            {
                btnNameFilter.SetBtnState(false);
            }
            else if (btnName == "Title")
            {
                btnTitleFilter.SetBtnState(false);
            }
        }
    }

    public class BtnFilterDataContext : INotifyPropertyChanged
    {
        #region PropertyChangedEventHandler
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaiseProperChanged([CallerMemberName] string propertyname = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion

        #region Image icon
        private string imagePath = ".\\Resources\\folder.png";
        public string ImagePath
        {
            get => imagePath;
            set
            {
                imagePath = value;
                RaiseProperChanged();
            }
        }
        public void SetBtnState(bool? isFilder)
        {
            if (isFilder != null)
            {
                ImagePath = isFilder == true ? ".\\Resources\\folder.png" : ".\\Resources\\close.png";
            }
        }
        #endregion

    }

    #endregion
}
