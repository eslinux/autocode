﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Controls;
using System.Windows.Data;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Tab2.xaml
    /// </summary>
    public partial class Tab2 : UserControl
    {
        DgvDataContextTab2 tab2DatContext = new DgvDataContextTab2();
        public Tab2()
        {
            InitializeComponent();
            DataContext = tab2DatContext;
        }

        private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            cb_test.IsThreeState = true;
            cb_test.IsChecked = null;
        }






        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Console.WriteLine("ComboBox_SelectionChanged: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }

        private void ComboBox_SourceUpdated(object sender, DataTransferEventArgs e)
        {
            Console.WriteLine("ComboBox_SourceUpdated: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }

        private void ComboBox_DropDownClosed(object sender, EventArgs e)
        {
            if (((ComboBox)sender).SelectedItem == null)
            {
                return;
            }

            Console.WriteLine("ComboBox_DropDownClosed: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }

        private void CheckBox_Checked(object sender, System.Windows.RoutedEventArgs e)
        {
            Console.WriteLine($"CheckBox_Checked");
            tab2DatContext.Title123 = "CheckBox_Checked";
        }

        private void CheckBox_Unchecked(object sender, System.Windows.RoutedEventArgs e)
        {
            Console.WriteLine($"CheckBox_Unchecked");
            tab2DatContext.Title123 = "CheckBox_Unchecked";
        }

        private void CheckBox_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            Console.WriteLine($"CheckBox_Click");
        }


    }

    public class DgvDataContextTab2 : INotifyPropertyChanged
    {
        #region PropertyChangedEventHandler
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaiseProperChanged([CallerMemberName] string propertyname = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion


        private string title123 = "Darling";

        public string Title123
        {
            get => title123;
            set
            {
                title123 = value;
                RaiseProperChanged();
            }
        }
    }
}
