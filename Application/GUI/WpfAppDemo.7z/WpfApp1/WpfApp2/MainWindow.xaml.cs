﻿using System.Windows;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnOpen_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("btnOpen_Click");
            OpenDlg dlgOpen = new OpenDlg
            {
                Owner = this
            };
            _ = dlgOpen.ShowDialog();
        }


        private void BtnRun_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("btnRun_Click");
            RunDlg dlgRun = new RunDlg();
            //dlgOpen.Owner = this;
            dlgRun.Show();
        }


    }
}
