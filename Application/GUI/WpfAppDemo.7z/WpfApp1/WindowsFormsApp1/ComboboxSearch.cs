﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace TestCombo
{
    public class ComboboxSearch
    {
        private readonly ToolStripDropDown dropdownItems = new ToolStripDropDown
        {
            AutoClose = false,
            AutoSize = false,
            Padding = Padding.Empty,
            Margin = Padding.Empty,
            DropShadowEnabled = true,
            CanOverflow = true,
            TabStop = true,
        };

        private readonly ListBox listboxItems = new ListBox
        {
            IntegralHeight = true,
            Margin = Padding.Empty,
            Padding = Padding.Empty,
            TabStop = false,
            Dock = DockStyle.Fill,
        };

        private readonly ToolTip toolTipdes = new ToolTip();

        private readonly ComboBox comboBox;
        private bool isSearching = false;

        public ComboboxSearch(ComboBox target)
        {
            //combobox
            comboBox = target;
            comboBox.DropDownStyle = ComboBoxStyle.DropDown;
            comboBox.AutoCompleteMode = AutoCompleteMode.None;
            comboBox.TextChanged += ComboBox_TextChanged;
            comboBox.DropDown += ComboBox_DropDown;
            comboBox.KeyDown += ComboBox_KeyDown;
            comboBox.LostFocus += ComboBox_LostFocus;
            comboBox.SizeChanged += ComboBox_SizeChanged;

            //listbox
            listboxItems.Click += ListBox_Click;
            listboxItems.MouseMove += ListBox_MouseMove;
            listboxItems.Size = new Size(comboBox.Size.Width, 150);
            listboxItems.Sorted = comboBox.Sorted;

            //dropdown
            ToolStripControlHost hostControl = new ToolStripControlHost(listboxItems)
            {
                Padding = Padding.Empty,
                Margin = Padding.Empty,
                AutoSize = false,
            };

            dropdownItems.MinimumSize = listboxItems.MinimumSize;
            dropdownItems.MaximumSize = listboxItems.MaximumSize;
            dropdownItems.Size = listboxItems.Size;
            _ = dropdownItems.Items.Add(hostControl);
            dropdownItems.Close();

            _ = new MouseClickIMessageFilter(comboBox, dropdownItems);
        }

        private void SearchItems()
        {
            string searchStr = comboBox.Text;
            listboxItems.BeginUpdate();
            listboxItems.Items.Clear();
            foreach (string item in comboBox.Items)
            {
                if (item.ToLower().Contains(searchStr.ToLower()))
                {
                    _ = listboxItems.Items.Add(item);
                }
            }
            listboxItems.EndUpdate();
        }
        public void HideDropDownItems()
        {
            if (dropdownItems.Visible)
            {
                dropdownItems.Close();
            }
        }
        public void ShowDropDownItems()
        {
            Point location = comboBox.Parent.PointToScreen(comboBox.Location);
            location.Offset(0, comboBox.Height);
            dropdownItems.Size = listboxItems.Size;
            dropdownItems.Show(location);
        }
        private void ComboBox_LostFocus(object sender, EventArgs e)
        {
            Console.WriteLine("comboBox_LostFocus: {0}", listboxItems.SelectedItem);
            if ((!listboxItems.Focused)
                && (!dropdownItems.Focused))
            {
                HideDropDownItems();
            }
        }
        private void ComboBox_LocationChanged(object sender, EventArgs e)
        {
            HideDropDownItems();
        }
        private void ComboBox_SizeChanged(object sender, EventArgs e)
        {
            dropdownItems.Width = comboBox.Width;
        }
        private void ComboBox_TextChanged(object sender, EventArgs e)
        {
            if ((!isSearching) || (!comboBox.Focused))
            {
                return;
            }
            isSearching = false;

            if (comboBox.DroppedDown)
            {
                comboBox.BeginUpdate();
                comboBox.DroppedDown = false;
                comboBox.EndUpdate();
            }

            //search match string
            SearchItems();

            //display search result
            if (listboxItems.Items.Count > 0)
            {
                ShowDropDownItems();
            }
            else
            {
                HideDropDownItems();
            }
        }
        private void ComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            Console.WriteLine("comboBox_KeyDown: {0}", e.KeyCode);

            isSearching = true;
            if (!dropdownItems.Visible)
            {
                return;
            }

            switch (e.KeyCode)
            {
                case Keys.Escape:
                    {
                        HideDropDownItems();
                    }
                    break;
                case Keys.Enter:
                    {
                        if (listboxItems.Text.Length != 0)
                        {
                            comboBox.Text = listboxItems.Text;
                        }
                        comboBox.Select(0, comboBox.Text.Length);
                        HideDropDownItems();
                    }
                    break;
                case Keys.Down:
                    {
                        if (listboxItems.SelectedIndex < 0)
                        {
                            listboxItems.SelectedIndex = 0;
                        }
                        else if (listboxItems.SelectedIndex < listboxItems.Items.Count - 1)
                        {
                            listboxItems.SelectedIndex++;
                        }
                    }
                    break;
                case Keys.Up:
                    {
                        if (listboxItems.SelectedIndex > 0)
                        {
                            listboxItems.SelectedIndex--;
                        }
                        else if (listboxItems.SelectedIndex < 0)
                        {
                            listboxItems.SelectedIndex = listboxItems.Items.Count - 1;
                        }
                    }
                    break;
                default:
                    return;
            }

            e.Handled = true;
            e.SuppressKeyPress = true;
        }
        private void ComboBox_DropDown(object sender, EventArgs e)
        {
            Console.WriteLine("comboBox_DropDown: {0}", comboBox.Text);
            isSearching = false;
            HideDropDownItems();
        }

        private void ListBox_Click(object sender, EventArgs e)
        {
            Console.WriteLine("listBox_Click: {0}", listboxItems.SelectedItem);
            isSearching = false;
            comboBox.Text = (string)listboxItems.SelectedItem;
            comboBox.Select(0, comboBox.Text.Length);
            _ = comboBox.Focus();
        }
        private void ListBox_MouseMove(object sender, MouseEventArgs e)
        {
            int indexItem = listboxItems.IndexFromPoint(e.Location);
            if ((indexItem >= 0) && (indexItem != listboxItems.SelectedIndex))
            {
                listboxItems.SelectedIndex = indexItem;
                toolTipdes.SetToolTip(listboxItems, listboxItems.SelectedItem.ToString());
            }
        }

        private class MouseClickIMessageFilter : IMessageFilter
        {
            private readonly ToolStripDropDown dropDownItem;
            private readonly ComboBox comboBox;

            public MouseClickIMessageFilter(ComboBox cb, ToolStripDropDown dropdown)
            {
                comboBox = cb;
                dropDownItem = dropdown;

                Application.AddMessageFilter(this);
            }

            [DllImport("user32.dll", ExactSpelling = true, CharSet = CharSet.Auto)]
            public static extern int MapWindowPoints(IntPtr hWndFrom, IntPtr hWndTo, [In, Out] ref Point pt, int cPoints);
            public bool PreFilterMessage(ref Message m)
            {
                if (!dropDownItem.Visible)
                {
                    return false;
                }

                switch (m.Msg)
                {
                    case 0x00A1://NCLBUTTONDOWN
                    case 0x00A4://NCRBUTTONDOWN
                    case 0x00A7://NCMBUTTONDOWN
                        dropDownItem.Close();
                        break;
                    case 0x0201://LBUTTONDOWN
                    case 0x0204://RBUTTONDOWN
                    case 0x0207://MBUTTONDOWN
                        {
                            int idx = unchecked((int)(long)m.LParam);
                            short posx = (short)(idx & 0xFFFF);
                            short posy = (short)((idx >> 16) & 0xffff);

                            Point clickedpos = new Point(posx, posy);
                            _ = MapWindowPoints(m.HWnd, dropDownItem.Handle, ref clickedpos, 1);
                            if (dropDownItem.ClientRectangle.Contains(clickedpos))
                            {
                                //clicked on dropdown
                                return false;
                            }

                            clickedpos = new Point(posx, posy);
                            _ = MapWindowPoints(m.HWnd, comboBox.Handle, ref clickedpos, 1);
                            if (comboBox.ClientRectangle.Contains(clickedpos))
                            {
                                //clicked on combobox
                                return false;
                            }

                            //close dropdown if clicked outside of dropdow and combobox
                            dropDownItem.Close();
                        }
                        break;
                    default:
                        break;
                }
                return false;
            }
        }
    }
}
