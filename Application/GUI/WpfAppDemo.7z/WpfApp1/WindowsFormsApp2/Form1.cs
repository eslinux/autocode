﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 12; i++)
            {
                DataGridViewTextBoxColumn col = new DataGridViewTextBoxColumn();
                _ = dataGridView1.Columns.Add(col);
            }

            for (int i = 0; i < 123; i++)
            {

                _ = dataGridView1.Rows.Add(i, i, i, i, i, i, i, i, i, i, i, i);

            }

        }
    }
}
