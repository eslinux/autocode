﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    //public partial class Window1 : Window
    //{
    //    public Window1()
    //    {
    //        InitializeComponent();
    //    }
    //}

    public partial class Window1 : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ObservableCollection<DataGridRowData2> _DataGridDataCollection;
        public ObservableCollection<DataGridRowData2> DataGridDataCollection
        {
            get => _DataGridDataCollection;
            set
            {
                _DataGridDataCollection = value;
                OnPropertyChanged();
            }
        }

        public Window1()
        {
            DataGridDataCollection = new ObservableCollection<DataGridRowData2>();
            InitializeComponent();
            this.DataContext = this;
            addChecks2();
        }

        // adds data to the DataGrid
        private void addChecks()
        {
            //for(int i = 0; i < 10; i++)
            //{

            //    DataGridDataCollection.Add(
            //    new DataGridRowData(new List<DataGridCellData>
            //    {
            //     new DataGridCellData(false,"Content 1_1"),
            //     new DataGridCellData(true,"Content 1_2"),
            //     new DataGridCellData(false,"Content 1_3"),
            //    }));

            //    DataGridDataCollection.Add(
            //    new DataGridRowData(new List<DataGridCellData>
            //    {
            //     new DataGridCellData(false,"Content 2_1"),
            //     new DataGridCellData(true,"Content 2_2"),
            //     new DataGridCellData(false,"Content 2_3"),
            //     new DataGridCellData(false,"Content 2_4"),
            //     new DataGridCellData(true,"Content 2_5")
            //    }));

            //    DataGridDataCollection.Add(
            //   new DataGridRowData(new List<DataGridCellData>
            //   {
            //     new DataGridCellData(false,"Content 3_1"),
            //     new DataGridCellData(true,"Content 3_2")
            //   }));
            //}
        }

        private void addChecks2()
        {
            for (int i = 0; i < 10; i++)
            {

                DataGridDataCollection.Add(
                new DataGridRowData2
                {
                    Check = true,
                    CheckContent = i.ToString()
                });


            }
        }


        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            Console.WriteLine("OnPropertyChanged: " + name);
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            //Console.WriteLine("CheckBox_Checked: " + cb.IsChecked);

            Console.WriteLine("\n<---->");
            foreach (var row in DataGridDataCollection)
            {
                //foreach (var row1 in row.Checks)
                //{
                //    Console.WriteLine("Content: {0}, check: {1}", row1.CheckContent, row1.Check);
                //}
                Console.WriteLine("Content: {0}, check: {1}", row.CheckContent, row.Check);
                //Console.WriteLine("--");
            }

        }
    }

    public class DataGridRowData
    {
        public List<DataGridCellData> Checks { get; set; }

        public string CheckContent { get; set; }
        public DataGridRowData(List<DataGridCellData> checks)
        {
            Checks = new List<DataGridCellData>();
            foreach (var b in checks)
            {
                Checks.Add(b);
            }
        }
    }

    public class DataGridRowData2
    {
        public bool Check { get; set; } = false;
        public string CheckContent { get; set; } = "";

    }

    public class DataGridCellData
    {
        public bool Check { get; set; }
        public string CheckContent { get; set; }
        public DataGridCellData(bool check, string checkContent)
        {
            Check = check;
            CheckContent = checkContent;
        }
    }
}
