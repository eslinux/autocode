﻿using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {

        public static DependencyProperty PercentageValueProperty =
          DependencyProperty.Register("settext", typeof(string), typeof(UserControl1));
        public string settext
        {
            get { return (string)GetValue(PercentageValueProperty); }
            set { SetValue(PercentageValueProperty, value); }
        }

        public UserControl1()
        {
            InitializeComponent();
        }



        private void cell_uc_Loaded(object sender, RoutedEventArgs e)
        {
            tb_name.Text = settext;
        }
    }
}
