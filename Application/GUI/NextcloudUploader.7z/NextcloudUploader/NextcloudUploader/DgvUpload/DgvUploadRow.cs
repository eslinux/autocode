﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace NextcloudUploader
{
    internal class DgvUploadRow : INotifyPropertyChanged
    {
        #region PropertyChangedEventHandler
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaiseProperChanged([CallerMemberName] string propertyname = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion


        #region Column field
        //item No
        private int mNo = 0;
        public int gNo
        {
            get => mNo;
            set
            {
                mNo = value;
                RaiseProperChanged();
            }
        }

        //item Enable
        private bool mEnable = true;
        public bool gEnable
        {
            get => mEnable;
            set
            {
                mEnable = value;
                RaiseProperChanged();
            }
        }

        //Filename
        private string mFile = string.Empty;
        public string gFile
        {
            get => mFile;
            set
            {
                mFile = value;
                RaiseProperChanged();
            }
        }

        //item Size
        private float mSize = 0.0f;
        public float gSize
        {
            get => mSize;
            set
            {
                mSize = value;
                RaiseProperChanged();
            }
        }

        //Status
        private string mStatus = string.Empty;
        public string gStatus
        {
            get => mStatus;
            set
            {
                mStatus = value;
                RaiseProperChanged();
            }
        }

        #endregion

    }
}
