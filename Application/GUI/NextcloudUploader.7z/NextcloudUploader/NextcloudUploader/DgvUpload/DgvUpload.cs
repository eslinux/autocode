﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Data;

namespace NextcloudUploader
{
    internal class DgvUpload
    {
        private object mLock = new object();
        private ObservableCollection<DgvUploadRow> mDgvRows = new ObservableCollection<DgvUploadRow>();

        //Instance delegate
        //private static DgvUpload? mInstance = null;
        //public static DgvUpload Instance
        //{
        //    get
        //    {
        //        if (mInstance == null)
        //            mInstance = new DgvUpload();
        //        return mInstance;
        //    }
        //}

        public DgvUpload()
        {
            BindingOperations.EnableCollectionSynchronization(this.mDgvRows, this.mLock);
        }

        public ObservableCollection<DgvUploadRow> GetDgvUploadRows()
        {
            return mDgvRows;
        }

        public void Add(String filePath)
        {
            if (!CheckFileExist(filePath))
            {
                return;
            }

            mDgvRows.Add(new DgvUploadRow()
            {
                gNo = mDgvRows.Count + 1,
                gFile = filePath,
                gSize = GetFileSize(filePath)
            });
        }

        public bool CheckFileExist(String filePath)
        {
            return File.Exists(filePath);
        }

        public float GetFileSize(String filePath)
        {
            long length = new FileInfo(filePath).Length;
            return (float)length/ (1024*1024);
        }

        public bool RemoveAll()
        {
            while (mDgvRows.Count > 0)
            {
                mDgvRows.RemoveAt(mDgvRows.Count - 1);
            }

            return true;
        }

        public int RowsCount()
        {
            return mDgvRows.Count;
        }

        #region Test data
        public bool GetStubData()
        {

            for (int i = 0; i < 100; i++)
            {
                mDgvRows.Add(new DgvUploadRow()
                {
                    gNo = mDgvRows.Count + 1,
                    gEnable = true,
                    gFile = $"my name {i}",
                    gSize = mDgvRows.Count + 1,
                    gStatus = String.Empty
                });

                Thread.Sleep(100);
            }

            return true;
        }

        #endregion
    }
}
