﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Threading;
using System.Windows.Threading;
using System.IO;
using System.Collections.ObjectModel;

namespace NextcloudUploader
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DataMng? mDataMng = null;
        private UploadSettings? mSettings = null;

        public MainWindow()
        {
            InitializeComponent();

            //Load Setting
            mSettings = new UploadSettings();

            //Data Manager
            mDataMng = new DataMng(mSettings);

            //Load UI Data
            LoadUIData();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SaveUIData();
        }

        #region UI
        private void LoadUIData()
        {
            if (mDataMng == null || mSettings == null)
            {
                return;
            }

            //TODO: not implement btnHiddenPW
            btnHiddenPW.Visibility = Visibility.Hidden;

            //Nextcloud account
            tbUsername.Text = mSettings.username;
            tbPassword.Password = mSettings.password;

            //Nextcloud destionation path
            tbNextcloudDesPath.Text = mSettings.nextcloud_destination_path;

            //Dgv Upload
            if (dgvFuploadFileList.ItemsSource == null)
            {
                dgvFuploadFileList.ItemsSource = mDataMng.GetDgvUploadRows();
            }
            dgvFuploadFileList.UpdateLayout();

            //Status bar
            UpdateStatusBar(0, 0, "...");
        }

        private void SaveUIData(bool isSave = true)
        {
            if (mSettings == null)
            {
                return;
            }

            mSettings.username = tbUsername.Text;
            mSettings.password = tbPassword.Password;
            mSettings.nextcloud_destination_path = tbNextcloudDesPath.Text;
            if (isSave)
            {
                mSettings.Save();
            }
        }

        private void UpdateStatusBar(int uploadedNum, int totalFile, String currentUploadFile)
        {
            tbProgress.Text = $"Progress: {uploadedNum}/{totalFile}";
            tbUploadingFile.Text = $"Uploading: {currentUploadFile}";
        }

        private void UpdateUploadState(bool isUploading)
        {
            btnBrowser.IsEnabled = !isUploading;
            btnClear.IsEnabled = !isUploading;
            tbUploadingFile.IsEnabled = isUploading;
            btnStartUpload.Content = isUploading ? "Cancel" : "Start";
        }

        private bool PreCheckUploadInfoValid()
        {
            if (mDataMng == null)
            {
                return false;
            }

            if (String.IsNullOrWhiteSpace(tbUsername.Text))
            {
                MessageBox.Show("Username is invalid !");
                return false;
            }

            if (String.IsNullOrWhiteSpace(tbPassword.Password))
            {
                MessageBox.Show("Password is invalid !");
                return false;
            }

            if (String.IsNullOrWhiteSpace(tbNextcloudDesPath.Text)
                || !mDataMng.PrepareUpload())
            {
                MessageBox.Show("Nextcloud destionation path is invalid !");
                return false;
            }

            if (mDataMng.UploadFileCount() == 0)
            {
                MessageBox.Show("Have no file to upload !");
                return false;
            }

            return true;
        }
        #endregion

        #region Event
        private async void btnBrowser_Click(object sender, RoutedEventArgs e)
        {
            if (mDataMng == null)
            {
                return;
            }

            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Multiselect = true;
            //openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (openFileDialog.ShowDialog() == true)
            {
                await Task.Run(() =>
                {
                    mDataMng.AddNewUploadFile(openFileDialog.FileNames);
                });
            }
        }

        private async void btnClear_Click(object sender, RoutedEventArgs e)
        {
            if (mDataMng == null)
            {
                return;
            }

            await Task.Run(() =>
            {
                mDataMng.RemoveAllUploadFile();
                //Dispatcher.BeginInvoke(new Action(() =>
                //{
                //    UpdateStatusBar(0, 0, "...");
                //}), DispatcherPriority.Background);
            });

            UpdateStatusBar(0, 0, "...");
        }

        private async void btnStartUpload_Click(object sender, RoutedEventArgs e)
        {
            if (mDataMng == null)
            {
                return;
            }

            SaveUIData(false);

            bool uploadvalid  = PreCheckUploadInfoValid();
            if (!uploadvalid)
            {
                return;
            }

            int uploadCount = 0;
            int totalFile = mDataMng.UploadFileCount();

            //clear all status
            ObservableCollection<DgvUploadRow> dgvRows = mDataMng.GetDgvUploadRows();
            foreach (var fileUpload in dgvRows)
            {
                fileUpload.gStatus = String.Empty;
            }

            //upload
            UpdateUploadState(true);
            foreach (var fileUpload in dgvRows)
            {
                if (!fileUpload.gEnable)
                {
                    continue;
                }

                if (!File.Exists(fileUpload.gFile))
                {
                    fileUpload.gStatus = "Failed (File not exists !)";
                    continue;
                }

                UpdateStatusBar(uploadCount, totalFile, fileUpload.gFile);
                fileUpload.gStatus = "Uploading...";

                bool ret = false;
                String curlCmd = mDataMng.CreateUploadCommand(fileUpload.gFile);
                await Task.Run(() =>
                {
                    ret = CmdUpload(curlCmd);
                });

                //updale status for last file
                fileUpload.gStatus = ret ? "Success" : "Failed";
                if (ret)
                {
                    uploadCount++;
                    UpdateStatusBar(uploadCount, totalFile, fileUpload.gFile);
                }
            }

            UpdateUploadState(false);
            MessageBox.Show("Finished");
        }

        private bool CmdUpload(String curlCmd)
        {
#if false
            #region OK
            Trace.WriteLine($"---> command start: {curlCmd}");
            Process process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.Start();


            StreamWriter sw = process.StandardInput;
            sw.WriteLine("curl --help");
            sw.WriteLine(curlCmd);
            sw.WriteLine("exit");
            string output = process.StandardOutput.ReadToEnd();
            process.WaitForExit();
            sw.Close();
            Trace.WriteLine($"---> command finished: {output}");
            #endregion
#endif


            //# git-bash
            //        https://demo1.nextcloud.com/apps/files/?dir=/Documents&fileid=23283601
            //↓
            //curl - X PUT - u "rL4RpSc6gcg3dWQc":"demo"  "https://demo1.nextcloud.com/remote.php/dav/files/rL4RpSc6gcg3dWQc/Documents/EA.exe" - T "/c/Users/user/Downloads/EA.exe"
            //curlCmd = "curl -X PUT -u \"nn4xgd7k5f5Bdm4W\":\"demo\"  \"https://demo1.nextcloud.com/remote.php/dav/files/rL4RpSc6gcg3dWQc/Documents/EA.exe\" -T \"/c/Users/user/Downloads/EA.exe\"";

            Trace.WriteLine($"---> command start: {curlCmd}");
            Process process = new Process();
            process.StartInfo.FileName = "C:\\Program Files\\Git\\git-bash.exe";
            process.StartInfo.Arguments = "-c \"" + curlCmd + "\"" ;
            process.Start();
            process.WaitForExit();
            process.Close();
            Trace.WriteLine($"---> command finished");

            return true;
        }

        private void btnHiddenPW_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnHelp_Click(object sender, RoutedEventArgs e)
        {

        }

        private async void dgvFuploadFileList_Drop(object sender, DragEventArgs e)
        {
            if (mDataMng == null)
            {
                return ;
            }
            await Task.Run(() =>
            {
                if (e.Data.GetDataPresent(DataFormats.FileDrop))
                {
                    String[] files = (String[])e.Data.GetData(DataFormats.FileDrop);
                    mDataMng.AddNewUploadFile(files);
                }
            });
        }
#endregion
    }
}
