﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NextcloudUploader
{
    internal class DataMng
    {
        private UploadSettings? mUploadSettings = null;
        private DgvUpload? mDgvUpload = null;
        private String mCurlCmdPre = String.Empty;

        public DataMng(UploadSettings setting)
        {
            mDgvUpload = new DgvUpload();
            mUploadSettings = setting;
            PrepareSetting();
        }

        private void PrepareSetting()
        {
            if (mUploadSettings == null)
            {
                return;
            }

            //set default if have not set yet
            if (String.IsNullOrWhiteSpace(mUploadSettings.nextcloud_path_pattern1))
            {
                mUploadSettings.nextcloud_path_pattern1 = "index.php/apps/files/?dir=";
            }
            if (String.IsNullOrWhiteSpace(mUploadSettings.nextcloud_path_pattern1_replace))
            {
                mUploadSettings.nextcloud_path_pattern1_replace = "remote.php/webdav/files";
            }
            if (String.IsNullOrWhiteSpace(mUploadSettings.nextcloud_path_pattern2))
            {
                mUploadSettings.nextcloud_path_pattern2 = "&fileid";
            }

            //to lower
            mUploadSettings.nextcloud_path_pattern1 = mUploadSettings.nextcloud_path_pattern1.ToLower();
            mUploadSettings.nextcloud_path_pattern1_replace = mUploadSettings.nextcloud_path_pattern1_replace.ToLower();
            mUploadSettings.nextcloud_path_pattern2 = mUploadSettings.nextcloud_path_pattern2.ToLower();
        }

        public ObservableCollection<DgvUploadRow> GetDgvUploadRows()
        {
            return mDgvUpload.GetDgvUploadRows();
        }

        public void AddNewUploadFile(String[] files)
        {
            foreach (var file in files)
            {
                mDgvUpload.Add(file);
            }
        }

        public void RemoveAllUploadFile()
        {
            mDgvUpload.RemoveAll();
        }

        public int UploadFileCount()
        {
            return mDgvUpload.RowsCount();
        }

        public bool PrepareUpload()
        {
            if (mUploadSettings == null)
            {
                return false;
            }

            //index.php/apps/files/?dir=
            //&fileid

            //curl -X PUT -u "LTGdyrwMGACoJM4Y":"demo"
            //"https://demo2.nextcloud.com/remote.php/webdav/files/LTGdyrwMGACoJM4Y/%E3%83%86%E3%82%B9%E3%83%88/myfile.zip"
            //-T "myfile.zip"

            //check format of nextcloud path
            mUploadSettings.nextcloud_destination_path = mUploadSettings.nextcloud_destination_path.ToLower();
            bool checkNextcloudPath = mUploadSettings.nextcloud_destination_path.Contains(mUploadSettings.nextcloud_path_pattern1)
                                     && mUploadSettings.nextcloud_destination_path.Contains(mUploadSettings.nextcloud_path_pattern2);
            if (!checkNextcloudPath)
            {
                return false;
            }

            //replace pattern 1
            String tmpStr = mUploadSettings.nextcloud_destination_path.Replace(mUploadSettings.nextcloud_path_pattern1
                , mUploadSettings.nextcloud_path_pattern1_replace);

            //cut pattern 2
            int pattern2Pos = tmpStr.LastIndexOf(mUploadSettings.nextcloud_path_pattern2);
            String tmpStr2 = tmpStr.Substring(0, pattern2Pos);
            
            #region Shell OK
            mCurlCmdPre = "curl -X PUT -u \"" + mUploadSettings.username + "\":\"" + mUploadSettings.password + "\" \"" + tmpStr2 + "/";
            #endregion

            return true;
        }

        public String CreateUploadCommand(String nextcloudPath)
        {
            String fileName = Path.GetFileName(nextcloudPath);
            nextcloudPath = ConvertWindowPathToLinuxPath(nextcloudPath);
            return mCurlCmdPre + fileName + "\" -T \"" + nextcloudPath + "\"";
        }

        public String ConvertWindowPathToLinuxPath(String windowsPath)
        {
            //Ex: C:\Users\user\Documents\GitHub
            //to -> /c/Users/user/Documents/GitHub
            String tmpStr = windowsPath.Replace('\\', '/');
            int removePos = tmpStr.IndexOf(":");
            tmpStr = tmpStr.Substring(0, removePos) + tmpStr.Substring(removePos+1);
            return "/" + tmpStr;
        }


    }
}
