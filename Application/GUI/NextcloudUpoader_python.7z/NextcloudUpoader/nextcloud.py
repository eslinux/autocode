#Usage:
#   nextcloud <"nextcloud path"> <"upload file name">


import sys
import time
import random
import datetime
import shlex
import subprocess
import os
import re
import signal

#Nextcloud Account
mUsername = "Doyfmjb6N3pj6xnB"
mPassword = "demo"

#Nextcoud path setting
mStartPattern = "index.php/apps/files/?dir="
mStartPatternReplace = "remote.php/webdav/files"
mEndPattern = "&fileid="

def nextcloudUpload(nextcloudPath, localFilePath):
    #Ex:
    #nextcloudPath: https://demo2.nextcloud.com/index.php/apps/files/?dir=/%E3%83%86%E3%82%B9%E3%83%88&fileid=23163452
    #localFilePath: myfile.zip

    pos1 = nextcloudPath.find(mStartPattern)
    pos2 = nextcloudPath.rfind(mEndPattern)
    
    if not (pos1 > 0 and pos2 > pos1) :
        print("Nextcloud path invalid !")
        return
    uploadFimename = os.path.basename(localFilePath)
    
    tmpPath = nextcloudPath.replace(mStartPattern, mStartPatternReplace)
    pos2 = tmpPath.rfind(mEndPattern)
    
    nextcloudFile = tmpPath[0:pos2] + "/" + uploadFimename
    cmdCurl = "curl -X PUT -u \"" + mUsername +"\":\"" + mPassword + "\" \"" + nextcloudFile + "\" -T \"" + localFilePath + "\""
    #print("\n\n", cmd)
    
    gitBashCmd = "\"C:\\Program Files\\Git\\git-bash.exe\" -c " + "\"" + cmdCurl + "\""
    print("\n\n", gitBashCmd)
    #"C:\Program Files\Git\git-bash.exe" -c "curl -X PUT -u "Doyfmjb6N3pj6xnB":"demo" "https://demo2.nextcloud.com/remote.php/webdav/files/%E3%83%86%E3%82%B9%E3%83%88/myfile.zip" -T "myfile.zip""

    gitBash = shlex.split(gitBashCmd)
    process = subprocess.Popen(gitBash, stdout=subprocess.PIPE)
    process.wait()
    for line in process.stdout:
        print(line)
    
        
def main():
    if len(sys.argv) < 3 :
        print("Error: Input arguments invalid \nUsage:\n   nextcloud <\"nextcloud path\"> <\"upload file name\"> ")
        return
    nextcloudUpload(sys.argv[1], sys.argv[2])

if __name__ == '__main__':
    main()
    