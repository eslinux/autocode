BASEDIR=$(dirname "$0")
python $BASEDIR/nextcloud.py $1 $2