﻿using System;
using System.Windows.Forms;
using TestCombo;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            _ = new ComboboxSearch(comboBox1);
            _ = comboBox1.Items.Add("anh yeu em eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
            _ = comboBox1.Items.Add("mai mai mot tinh yeu");
            _ = comboBox1.Items.Add("hoa no ko tan");
            _ = comboBox1.Items.Add("hoa hai duong");
        }

        private void addItems_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            for (int i = 0; i < 4000; i++)
            {
                _ = comboBox1.Items.Add($"hoa hai duong {i}");
            }
        }
    }
}
