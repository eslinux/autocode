﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {

        ObservableCollection<Employee> dgvData = new ObservableCollection<Employee>();
        public UserControl1()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        public void AddItems()
        {

        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("\n----->");
            foreach (var row in dgvData)
            {
                Console.WriteLine("Name: {0}, title: {1}, check: {2}", row.Name, row.Title, row.WasReElected);
            }
        }


        // adds data to the DataGrid
        public void addChecks()
        {
            dgvData = Employee.GetEmployees();
            dataGrid.ItemsSource = dgvData;

        }

        private void ckbSelectedAll_Checked(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("ckbSelectedAll_Checked");
        }
    }





    #region Dgv data source (INotifyPropertyChanged)
    public enum Party
    {
        Indepentent,
        Federalist,
        DemocratRepublican,
    }
    public class Employee : INotifyPropertyChanged
    {
        public Employee()
        {

        }

        #region PropertyChangedEventHandler
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaiseProperChanged([CallerMemberName] string caller = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(caller));
        }
        #endregion

        #region Column field
        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                RaiseProperChanged();
            }
        }

        private string title;

        public string Title
        {
            get { return title; }
            set
            {
                title = value;
                RaiseProperChanged();
            }
        }

        private bool wasReElected;

        public bool WasReElected
        {
            get { return wasReElected; }
            set
            {
                wasReElected = value;
                RaiseProperChanged();
            }
        }

        private Party affiliation;

        public Party Affiliation
        {
            get { return affiliation; }
            set
            {
                affiliation = value;
                RaiseProperChanged();
            }
        }
        #endregion

        public static ObservableCollection<Employee> GetEmployees()
        {
            var employees = new ObservableCollection<Employee>();


            for (int i = 0; i < 1; i++)
            {
                employees.Add(new Employee()
                {
                    Name = "Ali",
                    Title = "Minister",
                    WasReElected = true,
                    Affiliation = Party.Indepentent
                });

                employees.Add(new Employee()
                {
                    Name = "Ahmed",
                    Title = "CM",
                    WasReElected = false,
                    Affiliation = Party.Federalist
                });

                employees.Add(new Employee()
                {
                    Name = "Amjad",
                    Title = "PM",
                    WasReElected = true,
                    Affiliation = Party.DemocratRepublican
                });

                employees.Add(new Employee()
                {
                    Name = "Waqas",
                    Title = "Minister",
                    WasReElected = false,
                    Affiliation = Party.Indepentent
                });

                employees.Add(new Employee()
                {
                    Name = "Bilal",
                    Title = "Minister",
                    WasReElected = true,
                    Affiliation = Party.Federalist
                });

                employees.Add(new Employee()
                {
                    Name = "Waqar",
                    Title = "Minister",
                    WasReElected = false,
                    Affiliation = Party.DemocratRepublican
                });

            }


            return employees;
        }

    }
    #endregion

}
