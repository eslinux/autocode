﻿using System.Windows.Controls;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Interaction logic for UserControl2.xaml
    /// </summary>
    public partial class UserControl2 : UserControl
    {
        public UserControl2()
        {
            InitializeComponent();
        }

        public void AddItem()
        {

        }
    }
}
