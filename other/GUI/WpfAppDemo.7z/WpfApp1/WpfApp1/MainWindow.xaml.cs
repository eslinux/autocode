﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window/*, INotifyPropertyChanged*/
    {
        //public event PropertyChangedEventHandler PropertyChanged;

        private List<Student> student;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            for (int i = 0; i < 10; i++)
            {
                cbox.Items.Add(i.ToString());
            }
            cbox.Items.Add("anh yeu em");


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            student = new List<Student>();

            for (int i = 0; i < 1000; i++)
            {
                student.Add(new Student(18, "Peter", "Brian", i/*, i.ToString()*/));
            }


            datagrid.ItemsSource = student;


            //
            //Task.Run(() => cbox.);
            Task.Run(() => cbBlah.Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => addCbItems())));
        }

        void addCbItems()
        {
            cbBlah.Items.Clear();
            for (int i = 0; i < 5000; i++)
            {
                cbBlah.Items.Add(i.ToString());
            }
            cbBlah.Items.Add("anh yeu em");
        }

        private void datagrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }



        //protected void OnPropertyChanged([CallerMemberName] string name = null)
        //{
        //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        //}
    }

    public class Student
    {
        public Student(int id, String firstName, String lastName, double percentage/*, string tbtext*/)
        {
            ID = id;
            FirstName = firstName;
            LastName = lastName;
            Precentage = percentage;
            //mytext = tbtext;
        }

        public int ID
        { get; set; }

        public String FirstName
        { get; set; }

        public String LastName
        { get; set; }

        public double Precentage
        { get; set; }

        //public string mytext { get; set; }
        public bool isCheckFlag { get; set; } = true;
    }

}
