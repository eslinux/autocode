﻿using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for UserControl2.xaml
    /// </summary>
    public partial class UserControl2 : UserControl
    {
        public static DependencyProperty PercentageValueProperty =
           DependencyProperty.Register("PercentageValue", typeof(double), typeof(UserControl2));
        public double PercentageValue
        {
            get { return (double)GetValue(PercentageValueProperty); }
            set { SetValue(PercentageValueProperty, value); }
        }

        public UserControl2()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            percentage.Text = PercentageValue.ToString();
            if (PercentageValue < 50)
            {
                grade.Text = "Fail";
            }
            else if (PercentageValue >= 50 && PercentageValue < 60)
            {
                grade.Text = "D";
            }
            else if (PercentageValue >= 60 && PercentageValue < 70)
            {
                grade.Text = "C";
            }
            else if (PercentageValue >= 70 && PercentageValue < 80)
            {
                grade.Text = "B";
            }
            else if (PercentageValue >= 80)
            {
                grade.Text = "A";
            }
        }
    }
}
