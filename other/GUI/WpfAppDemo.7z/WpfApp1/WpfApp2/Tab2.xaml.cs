﻿using System;
using System.Windows.Controls;
using System.Windows.Data;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Tab2.xaml
    /// </summary>
    public partial class Tab2 : UserControl
    {
        public Tab2()
        {
            InitializeComponent();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Console.WriteLine("ComboBox_SelectionChanged: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }

        private void ComboBox_SourceUpdated(object sender, DataTransferEventArgs e)
        {
            Console.WriteLine("ComboBox_SourceUpdated: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }

        private void ComboBox_DropDownClosed(object sender, EventArgs e)
        {
            if (((ComboBox)sender).SelectedItem == null) return;
            Console.WriteLine("ComboBox_DropDownClosed: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }
    }
}
