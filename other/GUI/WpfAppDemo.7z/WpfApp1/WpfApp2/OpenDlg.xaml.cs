﻿using System;
using System.Windows;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for OpenDlg.xaml
    /// </summary>
    public partial class OpenDlg : Window
    {
        public OpenDlg()
        {
            InitializeComponent();
            Console.WriteLine("OpenDlg");
        }
    }
}
