﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Tab1.xaml
    /// </summary>
    public partial class Tab1 : UserControl
    {
        ObservableCollection<Employee> dgvData = new ObservableCollection<Employee>();

        public Tab1()
        {
            InitializeComponent();

        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("\n-------->");
            foreach (var row in dgvData)
            {
                Console.WriteLine("id: {0}, enable: {3}, value: {1}, type: {2}", row.ID, row.CbValue, row.CbType, row.WasReElected);
            }



            dgvData = Employee.GetEmployees(ref dgvData);


            if (dgvuser.ItemsSource == null)
            {
                ListCollectionView collectionView = new ListCollectionView(dgvData);
                collectionView.GroupDescriptions.Add(new PropertyGroupDescription("Name"));
                dgvuser.ItemsSource = collectionView;
            }

            dgvuser.UpdateLayout();
            //CollectionViewSource.GetDefaultView(dgvuser.ItemsSource).Refresh();
            //dgvuser.Items.Refresh();
            Console.WriteLine("Button_Click");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            dgvData.Clear();
            if (dgvuser.ItemsSource == null)
            {
                dgvuser.ItemsSource = dgvData;
            }
            dgvuser.Items.Refresh();
            Console.WriteLine("btnDelete_Click");
        }

        private void ckbEnable_Checked(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("ckbEnable_Checked: " + ((CheckBox)sender).IsChecked);
        }

        private void dgvuser_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            Console.WriteLine("dgvuser_CellEditEnding");
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Console.WriteLine("TextBox_TextChanged: " + ((TextBox)sender).Text);
        }

        private void dgvuser_CellEditEnding_1(object sender, DataGridCellEditEndingEventArgs e)
        {
            Console.WriteLine("dgvuser_CellEditEnding_1: row {0}, column: {1}", e.Row.GetIndex(), e.Column.Header.ToString());
        }



        private void cbValue_KeyUp(object sender, KeyEventArgs e)
        {
            Console.WriteLine("cbValue_KeyUp: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }

        private void cbType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Console.WriteLine("cbType_SelectionChanged: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }

        private void cbType_DropDownClosed(object sender, EventArgs e)
        {
            if (((ComboBox)sender).SelectedItem == null) return;
            Console.WriteLine("cbType_DropDownClosed: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);

            Employee rowvalue = dgvData[(int)((ComboBox)sender).Tag];
            rowvalue.CbValue = rowvalue.CbType;
        }

        private void cbValue_TextChanged(object sender, TextChangedEventArgs e)
        {
            Console.WriteLine("cbValue_TextChanged: RowIndex: {0}, Text: {1}", ((ComboBox)sender).Tag, ((ComboBox)sender).Text);
        }

        private void OnChecked(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("OnChecked: {0}", ((DataGridCell)sender).Content);
        }

        private void hiddenCol_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int col = int.Parse(tb_colIndex.Text);

                if (dgvuser.Columns[col].Visibility == Visibility.Hidden)
                {
                    dgvuser.Columns[col].Visibility = Visibility.Visible;
                }
                else
                {
                    dgvuser.Columns[col].Visibility = Visibility.Hidden;
                }
            }
            catch
            {

            }
        }
    }



    #region Dgv data source (INotifyPropertyChanged)

    public class Employee : INotifyPropertyChanged
    {
        #region PropertyChangedEventHandler
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaiseProperChanged([CallerMemberName] string propertyname = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion



        public Employee()
        {
            ValueItems = new List<string>();
            ValueItems.Add("anh yeu em");
            ValueItems.Add("mai mai mot tinh yeu");
            ValueItems.Add("tinh don phuong");

            TypeItems = new List<string>();
            TypeItems.Add("type 1");
            TypeItems.Add("type 2");
            TypeItems.Add("type 3");
            TypeItems.Add("type 5");
            TypeItems.Add("type 6");

        }

        #region Column field
        public bool IsInit { set; get; } = true;

        //row index
        public int RowIndex { set; get; } = 0;


        //item id
        private string id;

        public string ID
        {
            get { return id; }
            set
            {
                id = value;
                RaiseProperChanged();
            }
        }

        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                RaiseProperChanged();
            }
        }

        private string title;

        public string Title
        {
            get { return title; }
            set
            {
                title = value;
                RaiseProperChanged();
            }
        }

        private bool wasReElected;

        public bool WasReElected
        {
            get { return wasReElected; }
            set
            {
                wasReElected = value;
                RaiseProperChanged();
            }
        }

        public List<string> ValueItems { set; get; }

        private string cbValue;
        public string CbValue
        {
            get { return cbValue; }
            set
            {
                cbValue = value;
                RaiseProperChanged();
            }
        }


        public List<string> TypeItems { set; get; }
        private string cbType;
        public string CbType
        {
            get { return cbType; }
            set
            {
                cbType = value;
                RaiseProperChanged();

                //run other process
                //Console.WriteLine("set CbType: IsInit {0}", IsInit);
                if (IsInit) { return; }
                CbValue = cbType;
            }
        }


        #endregion

        #region Show info
        void ShowInfo(string propertyname)
        {
            if (propertyname == "CbType")
            {
                CbValue = CbType;

            }
            //Console.WriteLine("ID: {0}, Name: {1}, Title: {2}, WasReElected: {3}, Value: {4}, Type: {5}", 
            //    ID, Name, Title, WasReElected, CbValue, CbType);
        }
        #endregion

        #region Create data for datagrid
        public static ObservableCollection<Employee> GetEmployees(ref ObservableCollection<Employee> employees)
        {
            if (employees == null)
            {
                employees = new ObservableCollection<Employee>();
            }

            for (int i = 0; i < 1; i++)
            {
                employees.Add(new Employee()
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Ali",
                    Title = "Minister aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                    CbValue = "aa",
                    CbType = "type 1",
                    WasReElected = true
                }); ; ;

                employees.Add(new Employee()
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Ahmed",
                    Title = "CM",
                    CbValue = "bb",
                    CbType = "type 1",
                    WasReElected = false
                });

                employees.Add(new Employee()
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Amjad",
                    Title = "PM",
                    CbValue = "cc",
                    CbType = "type 1",
                    WasReElected = true

                });

                employees.Add(new Employee()
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Waqas",
                    Title = "Minister",
                    CbValue = "dd",
                    CbType = "type 1",
                    WasReElected = false
                });

                employees.Add(new Employee()
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Bilal",
                    Title = "Minister",
                    CbValue = "ee",
                    CbType = "type 1",
                    WasReElected = true
                });

                employees.Add(new Employee()
                {
                    RowIndex = employees.Count,
                    ID = (1 + employees.Count).ToString(),
                    Name = "Waqar",
                    Title = "Minister",
                    CbValue = "ff",
                    CbType = "type 1",
                    WasReElected = false
                });
            }

            foreach (var row in employees)
            {
                row.IsInit = false;
            }
            return employees;
        }
        #endregion

    }
    #endregion
}
