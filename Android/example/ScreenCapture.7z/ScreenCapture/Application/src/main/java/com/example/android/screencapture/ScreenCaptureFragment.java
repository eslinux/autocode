/*
 * Copyright (C) 2014 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.screencapture;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.ImageWriter;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.android.common.logger.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.Buffer;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Provides UI for the screen capture.
 */
public class ScreenCaptureFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = "ScreenCaptureFragment";

    private static final String STATE_RESULT_CODE = "result_code";
    private static final String STATE_RESULT_DATA = "result_data";

    private static final int REQUEST_MEDIA_PROJECTION = 1;

    private int mScreenDensity;

    private int mResultCode;
    private Intent mResultData;

    private Surface mSurfaceDisplay;


    private Surface mSurface;
    private MediaProjection mMediaProjection;
    private VirtualDisplay mVirtualDisplay;
    private MediaProjectionManager mMediaProjectionManager;
    private Button mButtonToggle;
    private SurfaceView mSurfaceView;

    private MediaRecorder mMediaRecorder;
    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();
    private boolean mIsRecording = false;

    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }

    ImageReader mImageReader;
    ImageWriter mImageWriter;

    private static final int DISPLAY_WIDTH = 838;
    private static final int DISPLAY_HEIGHT = 1277;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            mResultCode = savedInstanceState.getInt(STATE_RESULT_CODE);
            mResultData = savedInstanceState.getParcelable(STATE_RESULT_DATA);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_screen_capture, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        Log.i(TAG, "onViewCreated");

        mSurfaceView = (SurfaceView) view.findViewById(R.id.surface);
        mSurfaceDisplay = mSurfaceView.getHolder().getSurface();
        mButtonToggle = (Button) view.findViewById(R.id.toggle);
        mButtonToggle.setOnClickListener(this);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.i(TAG, "onActivityCreated");

        Activity activity = getActivity();
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        mScreenDensity = metrics.densityDpi;
        mMediaProjectionManager = (MediaProjectionManager) activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        mMediaRecorder = new MediaRecorder();

        mImageReader = ImageReader.newInstance(DISPLAY_WIDTH, DISPLAY_HEIGHT, PixelFormat.RGBA_8888, 2);
        mImageReader.setOnImageAvailableListener(mImageReaderOnImageAvailable, null);

        //        startDrawSurfaceSchedulerThread();
    }

    private int mSteepTime = 1000 / 30;
    private int mCount = 0;
    private ScheduledExecutorService mScheduledExecutorService = null;

    private void startDrawSurfaceSchedulerThread() {
        if (mIsStartSchedule) return;
        mIsStartSchedule = true;

        Log.i(TAG, "startDrawSurfaceSchedulerThread");
        mScheduledExecutorService = Executors.newScheduledThreadPool(1);
        mScheduledExecutorService.scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG, "loop draw -- start: " + mIsRecording + ", mSurface: " + mSurface);
                if (mSurface != null && mIsRecording && mSurfaceDisplay != null) {
                    try {
//                        Canvas canvas = mSurfaceDisplay.lockCanvas(null);
//                        if (canvas != null){
//                            Log.i(TAG, "loop draw ...");
//
//                            canvas.drawColor(Color.BLUE);
//                            mSurfaceDisplay.unlockCanvasAndPost(canvas);
//                            Thread.sleep(mSteepTime);
//                        }

                    } catch (Exception e) {
                        Log.e(TAG, "loop draw exception: " + e);
                    }
                }

                if (mCount == 1000) {
                    Log.i(TAG, "loop draw");
                    mCount = 0;
                }
                mCount++;
                Log.i(TAG, "loop draw -- stop");
            }
        }, 0, 1000, TimeUnit.MILLISECONDS);
    }

    private int fileIndex = 0;
    private ImageReader.OnImageAvailableListener mImageReaderOnImageAvailable = new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader imageReader) {
            Log.i(TAG, "onImageAvailable");
            Image image = imageReader.acquireLatestImage();
            if (image != null) {
//                final Image.Plane[] planes = image.getPlanes();
//                final Buffer buffer = planes[0].getBuffer().rewind();
//                int pixelStride = planes[0].getPixelStride();
//                int rowStride = planes[0].getRowStride();
//                int rowPadding = rowStride - pixelStride * DISPLAY_WIDTH;
//                Bitmap bitmap = Bitmap.createBitmap(DISPLAY_WIDTH + rowPadding / pixelStride, DISPLAY_HEIGHT, Bitmap.Config.ARGB_8888);
//                bitmap.copyPixelsFromBuffer(buffer);
//
//                String filename = Environment.getExternalStoragePublicDirectory(Environment
//                        .DIRECTORY_DOWNLOADS) + "/capture_" + fileIndex + ".png";
//                fileIndex++;
//
//                try (FileOutputStream out = new FileOutputStream(filename)) {
//                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }

                if (mIsRecording) {
                    try {
                        Log.i(TAG, "queueInputImage image.getFormat(): " + image.getFormat());
//                        Log.i(TAG, "mImageWriter.getFormat(): " + mImageWriter.getFormat());
//                        Image writeImg = mImageWriter.dequeueInputImage();
                        mImageWriter.queueInputImage(image);
                    } catch (Exception e) {
                        Log.e(TAG, "mImageWriter.queueInputImage exception: " + e);
                    }
                }

                image.close();
            }

        }
    };

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i(TAG, "onSaveInstanceState");

        if (mResultData != null) {
            outState.putInt(STATE_RESULT_CODE, mResultCode);
            outState.putParcelable(STATE_RESULT_DATA, mResultData);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.toggle:

//                try {
//                    if (!mIsRecording){
//                        startRecording(v);
//                        mIsRecording = true;
//                    } else {
//                        stopRecording(v);
//                        mIsRecording = false;
//                    }
//                } catch (Exception e) {
//                    Log.i(TAG, "recording exception: " + e);
//                }



                if (mVirtualDisplay == null) {
                    startScreenCapture();
                } else {
                    stopScreenCapture();
                }
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        android.util.Log.i(TAG, "onActivityResult request code: " + requestCode +
                ", result code: " + resultCode);

        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode != Activity.RESULT_OK) {
                Log.i(TAG, "User cancelled");
                Toast.makeText(getActivity(), R.string.user_cancelled, Toast.LENGTH_SHORT).show();
                return;
            }
            Activity activity = getActivity();
            if (activity == null) {
                return;
            }
            Log.i(TAG, "Starting screen capture");
            mResultCode = resultCode;
            mResultData = data;
            setUpMediaProjection();
            initRecorder();
            setUpVirtualDisplay();
            startMediaRecorder();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.i(TAG, "onPause");

        stopScreenCapture();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");

        tearDownMediaProjection();
    }

    private void setUpMediaProjection() {
        mMediaProjection = mMediaProjectionManager.getMediaProjection(mResultCode, mResultData);
    }

    private void tearDownMediaProjection() {
        if (mMediaProjection != null) {
            mMediaProjection.stop();
            mMediaProjection = null;
        }
    }

    private void startScreenCapture() {
        Activity activity = getActivity();
        if (activity == null) {
            return;
        }
        if (mMediaProjection != null) {
            initRecorder();
            setUpVirtualDisplay();
            startMediaRecorder();
        } else if (mResultCode != 0 && mResultData != null) {
            setUpMediaProjection();
            initRecorder();
            setUpVirtualDisplay();
            startMediaRecorder();
        } else {
            Log.i(TAG, "Requesting confirmation");
            // This initiates a prompt dialog for the user to confirm screen projection.
            startActivityForResult(
                    mMediaProjectionManager.createScreenCaptureIntent(),
                    REQUEST_MEDIA_PROJECTION);
        }
    }

    private void setUpVirtualDisplay() {
        Log.i(TAG, "->Setting up a VirtualDisplay: " +
                mSurfaceView.getWidth() + "x" + mSurfaceView.getHeight() +
                " (" + mScreenDensity + "), mMediaRecorder: " + mMediaRecorder);

        mVirtualDisplay = mMediaProjection.createVirtualDisplay("ScreenCapture",
                mSurfaceView.getWidth(), mSurfaceView.getHeight(), mScreenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mImageReader.getSurface(), null, null);

        mButtonToggle.setText(R.string.stop);
    }

    private void stopScreenCapture() {
        if (mVirtualDisplay == null) {
            return;
        }
        stopMediaRecorder();
        mVirtualDisplay.release();
        mVirtualDisplay = null;
        mButtonToggle.setText(R.string.start);
    }

    private void initRecorder() {
        Log.i(TAG, "initRecorder");

        try {
//            mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
//            mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
//            mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
//            mMediaRecorder.setOutputFile(Environment
//                    .getExternalStoragePublicDirectory(Environment
//                            .DIRECTORY_DOWNLOADS) + "/video.mp4");
//            mMediaRecorder.setVideoSize(DISPLAY_WIDTH, DISPLAY_HEIGHT);
//            mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
////            mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
////            mMediaRecorder.setInputSurface(mSurface);
//            mMediaRecorder.setVideoEncodingBitRate(512 * 1000);
//            mMediaRecorder.setVideoFrameRate(30);
//            int rotation = getActivity().getWindowManager().getDefaultDisplay().getRotation();
//            int orientation = ORIENTATIONS.get(rotation + 90);
//            mMediaRecorder.setOrientationHint(orientation);
//            mMediaRecorder.prepare();


            //Took audio out because emulator has no mic
            //mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.WEBM);//MPEG_4
            mMediaRecorder.setVideoEncodingBitRate(512 * 1000);
            //mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.VP8);//H264

            Log.i(TAG, "mSurfaceView.getWidth(): " + mSurfaceView.getWidth());
            Log.i(TAG, "mSurfaceView.getHeight(): " + mSurfaceView.getHeight());

            mMediaRecorder.setVideoSize(mSurfaceView.getWidth(), mSurfaceView.getHeight());
            mMediaRecorder.setVideoFrameRate(30);
            mMediaRecorder.setOutputFile(Environment.getExternalStoragePublicDirectory(Environment
                    .DIRECTORY_DOWNLOADS) + "/video2.mp4");
            mMediaRecorder.setPreviewDisplay(mSurfaceDisplay);

            mMediaRecorder.prepare();

            //Field variable to hold surface object
            //Deal with it as you see fit
            mSurface = mMediaRecorder.getSurface();
//            mImageWriter = ImageWriter.newInstance(mSurface, 1);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean mIsStartSchedule = false;

    private void startMediaRecorder() {
        try {
            mMediaRecorder.start();
            mIsRecording = true;
            Log.i(TAG, "startMediaRecorder: recording ...");

            mImageWriter = ImageWriter.newInstance(mSurface, 2);
//            startDrawSurfaceSchedulerThread();
        } catch (Exception e) {
            Log.e(TAG, "startMediaRecorder exception: " + e);
        }
    }

    private void stopMediaRecorder() {
        Log.i(TAG, "stopMediaRecorder: " + mMediaRecorder);
        try {
            mMediaRecorder.setOnErrorListener(null);
            mMediaRecorder.setOnInfoListener(null);
            mMediaRecorder.setPreviewDisplay(null);

            mMediaRecorder.stop();
            mMediaRecorder.reset();
            mIsRecording = false;
            Log.i(TAG, "stopMediaRecorder: stopped");

        } catch (Exception e) {
            Log.e(TAG, "stopMediaRecorder Exception: " + e);
        }
    }


    MediaRecorder recorder;
    File audiofile = null;

    public void startRecording(View view) throws IOException {

        //Creating file
        File dir = Environment.getExternalStoragePublicDirectory(Environment
                .DIRECTORY_DOWNLOADS);
        try {
            audiofile = File.createTempFile("sound", ".3gp", dir);
        } catch (IOException e) {
            Log.e(TAG, "external storage access error");
            return;
        }


        //Creating MediaRecorder and specifying audio source, output format, encoder & output format
        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        recorder.setOutputFile(audiofile.getAbsolutePath());
        recorder.prepare();
        recorder.start();
    }

    public void stopRecording(View view) {

        //stopping recorder
        recorder.stop();
        recorder.release();

    }


}
